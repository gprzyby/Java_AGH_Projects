package edu.labs.fourth_labs;

import java.awt.*;
import javax.swing.*;


public class FourthLabs {
    public static void main(String[] args) {
        Controller app = Controller.setApplication();
        app.run();
    }
}
