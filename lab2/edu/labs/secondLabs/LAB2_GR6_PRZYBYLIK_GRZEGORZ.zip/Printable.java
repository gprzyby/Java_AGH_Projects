package edu.labs.secondLabs;

interface Printable {
    public void printToStandartOutput();
}
