package edu.labs.third_labs.second_task;

public class ElementIntervalException extends IllegalArgumentException{
    public ElementIntervalException() {
    }

    public ElementIntervalException(String message) {
        super(message);
    }
}
