package edu.labs.third_labs.third_task;

public class NoSolutionExistException extends UnsupportedOperationException {
    public NoSolutionExistException() {}
    public NoSolutionExistException(String message) {
        super(message);
    }
}
