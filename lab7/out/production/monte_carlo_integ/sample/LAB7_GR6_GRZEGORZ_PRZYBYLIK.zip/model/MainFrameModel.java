package sample.model;

public class MainFrameModel {
    public static final double maxX = 8.0;
    public static final double maxY = 8.0;
    public static final double minX = -8.0;
    public static final double minY = -8.0;
}
